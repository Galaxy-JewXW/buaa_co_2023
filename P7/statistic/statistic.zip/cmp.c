#include <stdio.h>
#include <string.h>

int main() {
    char s1[400], s2[400];
    char s3[400], s4[400];
    int flag = 1;
    FILE* fp1;
    FILE* fp2;
    FILE* fp3;
    FILE* fp4;
    FILE* fp5;
    fp1 = fopen("mips_out_another.txt", "r");
    fp2 = fopen("isim_out.txt", "r");
    fp3 = fopen("result.txt", "w");
    fp4 = fopen("test.asm", "r");
    fp5 = fopen("error_code.asm", "w");
    int i = 0, j = 0;
    int n = 0;
    int line = 0;
    int l1 = 0, l2 = 0;
    while (fgets(s1, 400, fp1)) {
        line++;
        if (s1[0] == 'I') {
            fgets(s1, 400, fp1);
            fgets(s1, 400, fp1);
        }
        fgets(s2, 400, fp2);
        if (s2[0] == 'I') {
            fgets(s2, 400, fp2);
            fgets(s2, 400, fp2);
        }
        l1++;
        l2++;
        for (i = 0; s1[i] != '\0'; i++) {
            if (s1[i] == '@') {
                break;
            }
        }
        for (j = 0; s2[j] != '\0'; j++) {
            if (s2[j] == '@') {
                break;
            }
        }
        if (strcmp(s1 + i, s2 + j)) {
            fprintf(fp3, "Error in line %d\n", line);
            fprintf(fp3, "get   :%s", s1 + i);
            fprintf(fp3, "expect  :%s\n\n", s2 + j);
            flag = 0;
        }
    }
    if (flag) {
        fprintf(fp3, "Accept\n");
    } else {
        while (fgets(s3, 400, fp4)) {
            fputs(s3, fp5);
        }
    }
    fclose(fp1);
    fclose(fp2);
    fclose(fp3);
    return 0;
}
