/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static unsigned int ng0[] = {16768U, 0U};
static int ng1[] = {4, 0};
static unsigned int ng2[] = {3U, 0U};
static unsigned int ng3[] = {1U, 0U};
static unsigned int ng4[] = {0U, 0U};
static int ng5[] = {14, 0};
static unsigned int ng6[] = {2U, 0U};



static void Cont_36_0(char *t0)
{
    char t3[8];
    char t4[8];
    char t21[8];
    char t22[8];
    char t37[8];
    char t42[8];
    char t43[8];
    char t46[8];
    char t79[8];
    char t80[8];
    char t82[8];
    char t98[8];
    char t112[8];
    char t119[8];
    char t164[8];
    char t165[8];
    char t169[8];
    char t172[8];
    char t180[8];
    char t185[8];
    char t186[8];
    char t189[8];
    char t216[8];
    char t220[8];
    char t233[8];
    char t234[8];
    char t237[8];
    char t266[8];
    char t273[8];
    char *t1;
    char *t2;
    char *t5;
    unsigned int t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    char *t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t23;
    char *t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    char *t30;
    char *t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    char *t35;
    char *t36;
    unsigned int t38;
    unsigned int t39;
    unsigned int t40;
    unsigned int t41;
    char *t44;
    char *t45;
    char *t47;
    char *t48;
    unsigned int t49;
    unsigned int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    unsigned int t57;
    unsigned int t58;
    unsigned int t59;
    unsigned int t60;
    char *t61;
    char *t62;
    unsigned int t63;
    unsigned int t64;
    unsigned int t65;
    unsigned int t66;
    unsigned int t67;
    char *t68;
    char *t69;
    unsigned int t70;
    unsigned int t71;
    unsigned int t72;
    char *t73;
    char *t74;
    unsigned int t75;
    unsigned int t76;
    unsigned int t77;
    unsigned int t78;
    char *t81;
    char *t83;
    char *t84;
    unsigned int t85;
    unsigned int t86;
    unsigned int t87;
    unsigned int t88;
    unsigned int t89;
    unsigned int t90;
    unsigned int t91;
    unsigned int t92;
    unsigned int t93;
    unsigned int t94;
    unsigned int t95;
    unsigned int t96;
    char *t97;
    char *t99;
    unsigned int t100;
    unsigned int t101;
    unsigned int t102;
    unsigned int t103;
    unsigned int t104;
    char *t105;
    char *t106;
    unsigned int t107;
    unsigned int t108;
    unsigned int t109;
    char *t110;
    char *t111;
    unsigned int t113;
    unsigned int t114;
    unsigned int t115;
    unsigned int t116;
    unsigned int t117;
    char *t118;
    unsigned int t120;
    unsigned int t121;
    unsigned int t122;
    char *t123;
    char *t124;
    char *t125;
    unsigned int t126;
    unsigned int t127;
    unsigned int t128;
    unsigned int t129;
    unsigned int t130;
    unsigned int t131;
    unsigned int t132;
    char *t133;
    char *t134;
    unsigned int t135;
    unsigned int t136;
    unsigned int t137;
    unsigned int t138;
    unsigned int t139;
    unsigned int t140;
    unsigned int t141;
    unsigned int t142;
    int t143;
    int t144;
    unsigned int t145;
    unsigned int t146;
    unsigned int t147;
    unsigned int t148;
    unsigned int t149;
    unsigned int t150;
    char *t151;
    unsigned int t152;
    unsigned int t153;
    unsigned int t154;
    unsigned int t155;
    unsigned int t156;
    char *t157;
    char *t158;
    unsigned int t159;
    unsigned int t160;
    unsigned int t161;
    char *t162;
    char *t163;
    char *t166;
    char *t167;
    char *t168;
    char *t170;
    char *t171;
    char *t173;
    unsigned int t174;
    unsigned int t175;
    unsigned int t176;
    unsigned int t177;
    unsigned int t178;
    unsigned int t179;
    unsigned int t181;
    unsigned int t182;
    unsigned int t183;
    unsigned int t184;
    char *t187;
    char *t188;
    char *t190;
    char *t191;
    unsigned int t192;
    unsigned int t193;
    unsigned int t194;
    unsigned int t195;
    unsigned int t196;
    unsigned int t197;
    unsigned int t198;
    unsigned int t199;
    unsigned int t200;
    unsigned int t201;
    unsigned int t202;
    unsigned int t203;
    char *t204;
    char *t205;
    unsigned int t206;
    unsigned int t207;
    unsigned int t208;
    unsigned int t209;
    unsigned int t210;
    char *t211;
    char *t212;
    unsigned int t213;
    unsigned int t214;
    unsigned int t215;
    char *t217;
    char *t218;
    char *t219;
    char *t221;
    char *t222;
    unsigned int t223;
    unsigned int t224;
    unsigned int t225;
    unsigned int t226;
    unsigned int t227;
    unsigned int t228;
    unsigned int t229;
    unsigned int t230;
    unsigned int t231;
    unsigned int t232;
    char *t235;
    char *t236;
    char *t238;
    char *t239;
    unsigned int t240;
    unsigned int t241;
    unsigned int t242;
    unsigned int t243;
    unsigned int t244;
    unsigned int t245;
    unsigned int t246;
    unsigned int t247;
    unsigned int t248;
    unsigned int t249;
    unsigned int t250;
    unsigned int t251;
    char *t252;
    char *t253;
    unsigned int t254;
    unsigned int t255;
    unsigned int t256;
    unsigned int t257;
    unsigned int t258;
    char *t259;
    char *t260;
    unsigned int t261;
    unsigned int t262;
    unsigned int t263;
    char *t264;
    char *t265;
    unsigned int t267;
    unsigned int t268;
    unsigned int t269;
    unsigned int t270;
    char *t271;
    char *t272;
    char *t274;
    char *t275;
    char *t276;
    char *t277;
    char *t278;
    char *t279;

LAB0:    t1 = (t0 + 3808U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    t2 = (t0 + 2328U);
    t5 = *((char **)t2);
    memset(t4, 0, 8);
    t2 = (t5 + 4);
    t6 = *((unsigned int *)t2);
    t7 = (~(t6));
    t8 = *((unsigned int *)t5);
    t9 = (t8 & t7);
    t10 = (t9 & 1U);
    if (t10 != 0)
        goto LAB4;

LAB5:    if (*((unsigned int *)t2) != 0)
        goto LAB6;

LAB7:    t12 = (t4 + 4);
    t13 = *((unsigned int *)t4);
    t14 = *((unsigned int *)t12);
    t15 = (t13 || t14);
    if (t15 > 0)
        goto LAB8;

LAB9:    t17 = *((unsigned int *)t4);
    t18 = (~(t17));
    t19 = *((unsigned int *)t12);
    t20 = (t18 || t19);
    if (t20 > 0)
        goto LAB10;

LAB11:    if (*((unsigned int *)t12) > 0)
        goto LAB12;

LAB13:    if (*((unsigned int *)t4) > 0)
        goto LAB14;

LAB15:    memcpy(t3, t21, 8);

LAB16:    t274 = (t0 + 4208);
    t275 = (t274 + 56U);
    t276 = *((char **)t275);
    t277 = (t276 + 56U);
    t278 = *((char **)t277);
    memcpy(t278, t3, 8);
    xsi_driver_vfirst_trans(t274, 0, 31);
    t279 = (t0 + 4128);
    *((int *)t279) = 1;

LAB1:    return;
LAB4:    *((unsigned int *)t4) = 1;
    goto LAB7;

LAB6:    t11 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t11) = 1;
    goto LAB7;

LAB8:    t16 = ((char*)((ng0)));
    goto LAB9;

LAB10:    t23 = (t0 + 2488U);
    t24 = *((char **)t23);
    memset(t22, 0, 8);
    t23 = (t24 + 4);
    t25 = *((unsigned int *)t23);
    t26 = (~(t25));
    t27 = *((unsigned int *)t24);
    t28 = (t27 & t26);
    t29 = (t28 & 1U);
    if (t29 != 0)
        goto LAB17;

LAB18:    if (*((unsigned int *)t23) != 0)
        goto LAB19;

LAB20:    t31 = (t22 + 4);
    t32 = *((unsigned int *)t22);
    t33 = *((unsigned int *)t31);
    t34 = (t32 || t33);
    if (t34 > 0)
        goto LAB21;

LAB22:    t38 = *((unsigned int *)t22);
    t39 = (~(t38));
    t40 = *((unsigned int *)t31);
    t41 = (t39 || t40);
    if (t41 > 0)
        goto LAB23;

LAB24:    if (*((unsigned int *)t31) > 0)
        goto LAB25;

LAB26:    if (*((unsigned int *)t22) > 0)
        goto LAB27;

LAB28:    memcpy(t21, t42, 8);

LAB29:    goto LAB11;

LAB12:    xsi_vlog_unsigned_bit_combine(t3, 32, t16, 32, t21, 32);
    goto LAB16;

LAB14:    memcpy(t3, t16, 8);
    goto LAB16;

LAB17:    *((unsigned int *)t22) = 1;
    goto LAB20;

LAB19:    t30 = (t22 + 4);
    *((unsigned int *)t22) = 1;
    *((unsigned int *)t30) = 1;
    goto LAB20;

LAB21:    t35 = (t0 + 2168U);
    t36 = *((char **)t35);
    t35 = ((char*)((ng1)));
    memset(t37, 0, 8);
    xsi_vlog_unsigned_add(t37, 32, t36, 32, t35, 32);
    goto LAB22;

LAB23:    t44 = (t0 + 1368U);
    t45 = *((char **)t44);
    t44 = ((char*)((ng2)));
    memset(t46, 0, 8);
    t47 = (t45 + 4);
    t48 = (t44 + 4);
    t49 = *((unsigned int *)t45);
    t50 = *((unsigned int *)t44);
    t51 = (t49 ^ t50);
    t52 = *((unsigned int *)t47);
    t53 = *((unsigned int *)t48);
    t54 = (t52 ^ t53);
    t55 = (t51 | t54);
    t56 = *((unsigned int *)t47);
    t57 = *((unsigned int *)t48);
    t58 = (t56 | t57);
    t59 = (~(t58));
    t60 = (t55 & t59);
    if (t60 != 0)
        goto LAB33;

LAB30:    if (t58 != 0)
        goto LAB32;

LAB31:    *((unsigned int *)t46) = 1;

LAB33:    memset(t43, 0, 8);
    t62 = (t46 + 4);
    t63 = *((unsigned int *)t62);
    t64 = (~(t63));
    t65 = *((unsigned int *)t46);
    t66 = (t65 & t64);
    t67 = (t66 & 1U);
    if (t67 != 0)
        goto LAB34;

LAB35:    if (*((unsigned int *)t62) != 0)
        goto LAB36;

LAB37:    t69 = (t43 + 4);
    t70 = *((unsigned int *)t43);
    t71 = *((unsigned int *)t69);
    t72 = (t70 || t71);
    if (t72 > 0)
        goto LAB38;

LAB39:    t75 = *((unsigned int *)t43);
    t76 = (~(t75));
    t77 = *((unsigned int *)t69);
    t78 = (t76 || t77);
    if (t78 > 0)
        goto LAB40;

LAB41:    if (*((unsigned int *)t69) > 0)
        goto LAB42;

LAB43:    if (*((unsigned int *)t43) > 0)
        goto LAB44;

LAB45:    memcpy(t42, t79, 8);

LAB46:    goto LAB24;

LAB25:    xsi_vlog_unsigned_bit_combine(t21, 32, t37, 32, t42, 32);
    goto LAB29;

LAB27:    memcpy(t21, t37, 8);
    goto LAB29;

LAB32:    t61 = (t46 + 4);
    *((unsigned int *)t46) = 1;
    *((unsigned int *)t61) = 1;
    goto LAB33;

LAB34:    *((unsigned int *)t43) = 1;
    goto LAB37;

LAB36:    t68 = (t43 + 4);
    *((unsigned int *)t43) = 1;
    *((unsigned int *)t68) = 1;
    goto LAB37;

LAB38:    t73 = (t0 + 2008U);
    t74 = *((char **)t73);
    goto LAB39;

LAB40:    t73 = (t0 + 1368U);
    t81 = *((char **)t73);
    t73 = ((char*)((ng3)));
    memset(t82, 0, 8);
    t83 = (t81 + 4);
    t84 = (t73 + 4);
    t85 = *((unsigned int *)t81);
    t86 = *((unsigned int *)t73);
    t87 = (t85 ^ t86);
    t88 = *((unsigned int *)t83);
    t89 = *((unsigned int *)t84);
    t90 = (t88 ^ t89);
    t91 = (t87 | t90);
    t92 = *((unsigned int *)t83);
    t93 = *((unsigned int *)t84);
    t94 = (t92 | t93);
    t95 = (~(t94));
    t96 = (t91 & t95);
    if (t96 != 0)
        goto LAB50;

LAB47:    if (t94 != 0)
        goto LAB49;

LAB48:    *((unsigned int *)t82) = 1;

LAB50:    memset(t98, 0, 8);
    t99 = (t82 + 4);
    t100 = *((unsigned int *)t99);
    t101 = (~(t100));
    t102 = *((unsigned int *)t82);
    t103 = (t102 & t101);
    t104 = (t103 & 1U);
    if (t104 != 0)
        goto LAB51;

LAB52:    if (*((unsigned int *)t99) != 0)
        goto LAB53;

LAB54:    t106 = (t98 + 4);
    t107 = *((unsigned int *)t98);
    t108 = *((unsigned int *)t106);
    t109 = (t107 || t108);
    if (t109 > 0)
        goto LAB55;

LAB56:    memcpy(t119, t98, 8);

LAB57:    memset(t80, 0, 8);
    t151 = (t119 + 4);
    t152 = *((unsigned int *)t151);
    t153 = (~(t152));
    t154 = *((unsigned int *)t119);
    t155 = (t154 & t153);
    t156 = (t155 & 1U);
    if (t156 != 0)
        goto LAB65;

LAB66:    if (*((unsigned int *)t151) != 0)
        goto LAB67;

LAB68:    t158 = (t80 + 4);
    t159 = *((unsigned int *)t80);
    t160 = *((unsigned int *)t158);
    t161 = (t159 || t160);
    if (t161 > 0)
        goto LAB69;

LAB70:    t181 = *((unsigned int *)t80);
    t182 = (~(t181));
    t183 = *((unsigned int *)t158);
    t184 = (t182 || t183);
    if (t184 > 0)
        goto LAB71;

LAB72:    if (*((unsigned int *)t158) > 0)
        goto LAB73;

LAB74:    if (*((unsigned int *)t80) > 0)
        goto LAB75;

LAB76:    memcpy(t79, t185, 8);

LAB77:    goto LAB41;

LAB42:    xsi_vlog_unsigned_bit_combine(t42, 32, t74, 32, t79, 32);
    goto LAB46;

LAB44:    memcpy(t42, t74, 8);
    goto LAB46;

LAB49:    t97 = (t82 + 4);
    *((unsigned int *)t82) = 1;
    *((unsigned int *)t97) = 1;
    goto LAB50;

LAB51:    *((unsigned int *)t98) = 1;
    goto LAB54;

LAB53:    t105 = (t98 + 4);
    *((unsigned int *)t98) = 1;
    *((unsigned int *)t105) = 1;
    goto LAB54;

LAB55:    t110 = (t0 + 1528U);
    t111 = *((char **)t110);
    memset(t112, 0, 8);
    t110 = (t111 + 4);
    t113 = *((unsigned int *)t110);
    t114 = (~(t113));
    t115 = *((unsigned int *)t111);
    t116 = (t115 & t114);
    t117 = (t116 & 1U);
    if (t117 != 0)
        goto LAB58;

LAB59:    if (*((unsigned int *)t110) != 0)
        goto LAB60;

LAB61:    t120 = *((unsigned int *)t98);
    t121 = *((unsigned int *)t112);
    t122 = (t120 & t121);
    *((unsigned int *)t119) = t122;
    t123 = (t98 + 4);
    t124 = (t112 + 4);
    t125 = (t119 + 4);
    t126 = *((unsigned int *)t123);
    t127 = *((unsigned int *)t124);
    t128 = (t126 | t127);
    *((unsigned int *)t125) = t128;
    t129 = *((unsigned int *)t125);
    t130 = (t129 != 0);
    if (t130 == 1)
        goto LAB62;

LAB63:
LAB64:    goto LAB57;

LAB58:    *((unsigned int *)t112) = 1;
    goto LAB61;

LAB60:    t118 = (t112 + 4);
    *((unsigned int *)t112) = 1;
    *((unsigned int *)t118) = 1;
    goto LAB61;

LAB62:    t131 = *((unsigned int *)t119);
    t132 = *((unsigned int *)t125);
    *((unsigned int *)t119) = (t131 | t132);
    t133 = (t98 + 4);
    t134 = (t112 + 4);
    t135 = *((unsigned int *)t98);
    t136 = (~(t135));
    t137 = *((unsigned int *)t133);
    t138 = (~(t137));
    t139 = *((unsigned int *)t112);
    t140 = (~(t139));
    t141 = *((unsigned int *)t134);
    t142 = (~(t141));
    t143 = (t136 & t138);
    t144 = (t140 & t142);
    t145 = (~(t143));
    t146 = (~(t144));
    t147 = *((unsigned int *)t125);
    *((unsigned int *)t125) = (t147 & t145);
    t148 = *((unsigned int *)t125);
    *((unsigned int *)t125) = (t148 & t146);
    t149 = *((unsigned int *)t119);
    *((unsigned int *)t119) = (t149 & t145);
    t150 = *((unsigned int *)t119);
    *((unsigned int *)t119) = (t150 & t146);
    goto LAB64;

LAB65:    *((unsigned int *)t80) = 1;
    goto LAB68;

LAB67:    t157 = (t80 + 4);
    *((unsigned int *)t80) = 1;
    *((unsigned int *)t157) = 1;
    goto LAB68;

LAB69:    t162 = (t0 + 1208U);
    t163 = *((char **)t162);
    t162 = ((char*)((ng1)));
    memset(t164, 0, 8);
    xsi_vlog_unsigned_add(t164, 32, t163, 32, t162, 32);
    t166 = ((char*)((ng4)));
    t167 = (t0 + 1848U);
    t168 = *((char **)t167);
    t167 = ((char*)((ng5)));
    t170 = (t0 + 1848U);
    t171 = *((char **)t170);
    memset(t172, 0, 8);
    t170 = (t172 + 4);
    t173 = (t171 + 4);
    t174 = *((unsigned int *)t171);
    t175 = (t174 >> 15);
    t176 = (t175 & 1);
    *((unsigned int *)t172) = t176;
    t177 = *((unsigned int *)t173);
    t178 = (t177 >> 15);
    t179 = (t178 & 1);
    *((unsigned int *)t170) = t179;
    xsi_vlog_mul_concat(t169, 14, 1, t167, 1U, t172, 1);
    xsi_vlogtype_concat(t165, 32, 32, 3U, t169, 14, t168, 16, t166, 2);
    memset(t180, 0, 8);
    xsi_vlog_unsigned_add(t180, 32, t164, 32, t165, 32);
    goto LAB70;

LAB71:    t187 = (t0 + 1368U);
    t188 = *((char **)t187);
    t187 = ((char*)((ng6)));
    memset(t189, 0, 8);
    t190 = (t188 + 4);
    t191 = (t187 + 4);
    t192 = *((unsigned int *)t188);
    t193 = *((unsigned int *)t187);
    t194 = (t192 ^ t193);
    t195 = *((unsigned int *)t190);
    t196 = *((unsigned int *)t191);
    t197 = (t195 ^ t196);
    t198 = (t194 | t197);
    t199 = *((unsigned int *)t190);
    t200 = *((unsigned int *)t191);
    t201 = (t199 | t200);
    t202 = (~(t201));
    t203 = (t198 & t202);
    if (t203 != 0)
        goto LAB81;

LAB78:    if (t201 != 0)
        goto LAB80;

LAB79:    *((unsigned int *)t189) = 1;

LAB81:    memset(t186, 0, 8);
    t205 = (t189 + 4);
    t206 = *((unsigned int *)t205);
    t207 = (~(t206));
    t208 = *((unsigned int *)t189);
    t209 = (t208 & t207);
    t210 = (t209 & 1U);
    if (t210 != 0)
        goto LAB82;

LAB83:    if (*((unsigned int *)t205) != 0)
        goto LAB84;

LAB85:    t212 = (t186 + 4);
    t213 = *((unsigned int *)t186);
    t214 = *((unsigned int *)t212);
    t215 = (t213 || t214);
    if (t215 > 0)
        goto LAB86;

LAB87:    t229 = *((unsigned int *)t186);
    t230 = (~(t229));
    t231 = *((unsigned int *)t212);
    t232 = (t230 || t231);
    if (t232 > 0)
        goto LAB88;

LAB89:    if (*((unsigned int *)t212) > 0)
        goto LAB90;

LAB91:    if (*((unsigned int *)t186) > 0)
        goto LAB92;

LAB93:    memcpy(t185, t233, 8);

LAB94:    goto LAB72;

LAB73:    xsi_vlog_unsigned_bit_combine(t79, 32, t180, 32, t185, 32);
    goto LAB77;

LAB75:    memcpy(t79, t180, 8);
    goto LAB77;

LAB80:    t204 = (t189 + 4);
    *((unsigned int *)t189) = 1;
    *((unsigned int *)t204) = 1;
    goto LAB81;

LAB82:    *((unsigned int *)t186) = 1;
    goto LAB85;

LAB84:    t211 = (t186 + 4);
    *((unsigned int *)t186) = 1;
    *((unsigned int *)t211) = 1;
    goto LAB85;

LAB86:    t217 = ((char*)((ng4)));
    t218 = (t0 + 1688U);
    t219 = *((char **)t218);
    t218 = (t0 + 1208U);
    t221 = *((char **)t218);
    memset(t220, 0, 8);
    t218 = (t220 + 4);
    t222 = (t221 + 4);
    t223 = *((unsigned int *)t221);
    t224 = (t223 >> 28);
    *((unsigned int *)t220) = t224;
    t225 = *((unsigned int *)t222);
    t226 = (t225 >> 28);
    *((unsigned int *)t218) = t226;
    t227 = *((unsigned int *)t220);
    *((unsigned int *)t220) = (t227 & 15U);
    t228 = *((unsigned int *)t218);
    *((unsigned int *)t218) = (t228 & 15U);
    xsi_vlogtype_concat(t216, 32, 32, 3U, t220, 4, t219, 26, t217, 2);
    goto LAB87;

LAB88:    t235 = (t0 + 1368U);
    t236 = *((char **)t235);
    t235 = ((char*)((ng4)));
    memset(t237, 0, 8);
    t238 = (t236 + 4);
    t239 = (t235 + 4);
    t240 = *((unsigned int *)t236);
    t241 = *((unsigned int *)t235);
    t242 = (t240 ^ t241);
    t243 = *((unsigned int *)t238);
    t244 = *((unsigned int *)t239);
    t245 = (t243 ^ t244);
    t246 = (t242 | t245);
    t247 = *((unsigned int *)t238);
    t248 = *((unsigned int *)t239);
    t249 = (t247 | t248);
    t250 = (~(t249));
    t251 = (t246 & t250);
    if (t251 != 0)
        goto LAB98;

LAB95:    if (t249 != 0)
        goto LAB97;

LAB96:    *((unsigned int *)t237) = 1;

LAB98:    memset(t234, 0, 8);
    t253 = (t237 + 4);
    t254 = *((unsigned int *)t253);
    t255 = (~(t254));
    t256 = *((unsigned int *)t237);
    t257 = (t256 & t255);
    t258 = (t257 & 1U);
    if (t258 != 0)
        goto LAB99;

LAB100:    if (*((unsigned int *)t253) != 0)
        goto LAB101;

LAB102:    t260 = (t234 + 4);
    t261 = *((unsigned int *)t234);
    t262 = *((unsigned int *)t260);
    t263 = (t261 || t262);
    if (t263 > 0)
        goto LAB103;

LAB104:    t267 = *((unsigned int *)t234);
    t268 = (~(t267));
    t269 = *((unsigned int *)t260);
    t270 = (t268 || t269);
    if (t270 > 0)
        goto LAB105;

LAB106:    if (*((unsigned int *)t260) > 0)
        goto LAB107;

LAB108:    if (*((unsigned int *)t234) > 0)
        goto LAB109;

LAB110:    memcpy(t233, t273, 8);

LAB111:    goto LAB89;

LAB90:    xsi_vlog_unsigned_bit_combine(t185, 32, t216, 32, t233, 32);
    goto LAB94;

LAB92:    memcpy(t185, t216, 8);
    goto LAB94;

LAB97:    t252 = (t237 + 4);
    *((unsigned int *)t237) = 1;
    *((unsigned int *)t252) = 1;
    goto LAB98;

LAB99:    *((unsigned int *)t234) = 1;
    goto LAB102;

LAB101:    t259 = (t234 + 4);
    *((unsigned int *)t234) = 1;
    *((unsigned int *)t259) = 1;
    goto LAB102;

LAB103:    t264 = (t0 + 1048U);
    t265 = *((char **)t264);
    t264 = ((char*)((ng1)));
    memset(t266, 0, 8);
    xsi_vlog_unsigned_add(t266, 32, t265, 32, t264, 32);
    goto LAB104;

LAB105:    t271 = (t0 + 1048U);
    t272 = *((char **)t271);
    t271 = ((char*)((ng1)));
    memset(t273, 0, 8);
    xsi_vlog_unsigned_add(t273, 32, t272, 32, t271, 32);
    goto LAB106;

LAB107:    xsi_vlog_unsigned_bit_combine(t233, 32, t266, 32, t273, 32);
    goto LAB111;

LAB109:    memcpy(t233, t266, 8);
    goto LAB111;

}


extern void work_m_00000000004225036787_3146453351_init()
{
	static char *pe[] = {(void *)Cont_36_0};
	xsi_register_didat("work_m_00000000004225036787_3146453351", "isim/mips.exe.sim/work/m_00000000004225036787_3146453351.didat");
	xsi_register_executes(pe);
}
